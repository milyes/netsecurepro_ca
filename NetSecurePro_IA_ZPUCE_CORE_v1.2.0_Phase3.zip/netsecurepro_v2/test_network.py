# Test Phase 3 — Réseau Distribué
# NetSecurePro IA — Mohammed Ilyes Zoubirou

from distributed.network import ZPUCE_P2P
import time

print("=" * 50)
print("  NETSECUREPRO IA — PHASE 3")
print("  Réseau Distribué ZPUCE")
print("  Fondateur : Mohammed Ilyes Zoubirou")
print("=" * 50)

# Démarrer 3 nœuds locaux
main = ZPUCE_P2P("ZPUCE_MAIN", port=5000)
n1   = ZPUCE_P2P("ZPUCE_001",  port=5001)
n2   = ZPUCE_P2P("ZPUCE_002",  port=5002)

main.start()
n1.start()
n2.start()

time.sleep(0.5)

# Connecter les nœuds
main.connect_peer("ZPUCE_001", "127.0.0.1", 5001)
main.connect_peer("ZPUCE_002", "127.0.0.1", 5002)

# Broadcast souverain
main.broadcast({"cmd": "PING", "source": "LOCAL"})

# Test rejet non-souverain
print("\n🔴 Test rejet message non-souverain :")
main.send("ZPUCE_001", {"cmd": "HACK", "sovereignty": "CLOUD"})

# Topologie
main.topology()

print("\n✅ Phase 3 — Réseau Distribué LOCAL opérationnel")
print("=" * 50)
