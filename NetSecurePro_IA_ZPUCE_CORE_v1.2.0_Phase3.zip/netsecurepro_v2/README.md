# 🛡️ NetSecurePro IA — IA_ZPUCE_CORE

**Fondateur** : Mohammed Ilyes Zoubirou  
**Email** : MILYES@NETSECUREPRO.CA  
**Site** : https://netsecurepro.ca  
**Version** : 1.2.0 | **Souveraineté** : LOCAL_ONLY  

---

## Structure

```
netsecurepro/
├── main.py                       # Point d'entrée
├── test_network.py               # Test Phase 3
├── config.json                   # Configuration
├── zcore/core.py                 # Cerveau IA_ZPUCE_CORE
├── security/netsecurepro.py      # Shield cognitif
├── memory/ledger.py              # Ledger immuable
├── perception/fusion.py          # Fusion de perception
├── distributed/
│   ├── zpuce.py                  # Gestion nœuds
│   └── network.py                # Réseau P2P Phase 3
└── zpuce_esp32/
    ├── main.py                   # MicroPython ESP32
    └── flash_instructions.sh     # Instructions flash
```

---

## Lancer

```bash
# Phase 1+2
python main.py

# Phase 3 — Réseau distribué
python test_network.py
```

---

## Phases

- ✅ Phase 1 — Logiciel complet
- ✅ Phase 2 — Simulation ESP32 réussie
- ✅ Phase 3 — Réseau P2P distribué
- ⏳ Phase 4 — Puce FPGA

---

© NetSecurePro IA — Mohammed Ilyes Zoubirou
