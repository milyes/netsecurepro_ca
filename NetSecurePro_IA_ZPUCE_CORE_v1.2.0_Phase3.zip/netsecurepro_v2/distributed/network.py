# Réseau P2P Distribué — NetSecurePro IA
# Fondateur : Mohammed Ilyes Zoubirou
# MILYES@NETSECUREPRO.CA

import socket
import json
import threading
import datetime

class ZPUCE_P2P:
    def __init__(self, node_id, port=5000):
        self.node_id = node_id
        self.port = port
        self.peers = {}
        self.sovereignty = "LOCAL_ONLY"
        self.running = False
        self.ledger = []

    def start(self):
        self.running = True
        t = threading.Thread(target=self._listen)
        t.daemon = True
        t.start()
        print(f"📡 Nœud {self.node_id} actif — port {self.port}")

    def _listen(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", self.port))
        srv.listen(5)
        while self.running:
            try:
                conn, addr = srv.accept()
                threading.Thread(target=self._handle, args=(conn, addr)).start()
            except:
                break

    def _handle(self, conn, addr):
        try:
            data = conn.recv(1024).decode()
            msg = json.loads(data)
            if msg.get("sovereignty") != "LOCAL_ONLY":
                response = {"status": "REJECTED", "reason": "NON_SOVEREIGN"}
            else:
                response = {
                    "status": "OK",
                    "from": self.node_id,
                    "timestamp": str(datetime.datetime.now())
                }
                self._seal(msg)
            conn.send(json.dumps(response).encode())
        finally:
            conn.close()

    def _seal(self, event):
        event["received_by"] = self.node_id
        event["timestamp"] = str(datetime.datetime.now())
        self.ledger.append(event)

    def connect_peer(self, peer_id, host, port):
        self.peers[peer_id] = {"host": host, "port": port}
        print(f"🔗 Pair ajouté : {peer_id} @ {host}:{port}")

    def send(self, peer_id, message):
        if peer_id not in self.peers:
            print(f"❌ Pair inconnu : {peer_id}")
            return None
        peer = self.peers[peer_id]
        message["sovereignty"] = "LOCAL_ONLY"
        message["from"] = self.node_id
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(3)
            s.connect((peer["host"], peer["port"]))
            s.send(json.dumps(message).encode())
            response = json.loads(s.recv(1024).decode())
            s.close()
            print(f"  ✅ {peer_id} → {response['status']}")
            return response
        except Exception as e:
            print(f"  🔴 Erreur {peer_id} : {e}")
            return None

    def broadcast(self, message):
        print(f"📡 Broadcast LOCAL → {len(self.peers)} nœuds")
        results = {}
        for peer_id in self.peers:
            results[peer_id] = self.send(peer_id, message.copy())
        return results

    def topology(self):
        print(f"\n🌐 Réseau P2P LOCAL — {len(self.peers)} pairs connectés")
        for pid, info in self.peers.items():
            print(f"   [{pid}] {info['host']}:{info['port']}")
        print(f"   Ledger local : {len(self.ledger)} événements")

    def stop(self):
        self.running = False
        print(f"🔴 Nœud {self.node_id} arrêté")
