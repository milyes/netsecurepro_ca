# IA_ZPUCE_CORE — MicroPython ESP32
# Fondateur : Mohammed Ilyes Zoubirou
# MILYES@NETSECUREPRO.CA | Version 1.0.0

import bluetooth, json, time, machine

class ZPUCE_CORE:
    def __init__(self):
        self.id = "ZPUCE_001"
        self.founder = "Mohammed Ilyes Zoubirou"
        self.sovereignty = "LOCAL_ONLY"
        self.status = "STANDBY"
        self.led = machine.Pin(2, machine.Pin.OUT)

    def boot(self):
        print("=" * 40)
        print(f"  IA_ZPUCE_CORE — ESP32 BOOT")
        print(f"  ID : {self.id} | Mode : {self.sovereignty}")
        print("=" * 40)
        self.led_blink(3)
        self.status = "ACTIVE"

    def perceive(self, data):
        if data.get("source") != "LOCAL":
            self.led_alert()
            return {"status": "REJECTED", "reason": "EXTERNAL_ATTEMPT"}
        return {"status": "ACCEPTED", "zpuce_id": self.id}

    def decide(self, perception):
        if perception["status"] == "REJECTED":
            print("🔴 LOCKDOWN")
            return perception
        print("✅ LOCAL ACCEPTÉ")
        return {"action": "EXECUTE", "confidence": 100.0}

    def led_blink(self, n):
        for _ in range(n):
            self.led.on(); time.sleep(0.2)
            self.led.off(); time.sleep(0.2)

    def led_alert(self):
        for _ in range(10):
            self.led.on(); time.sleep(0.05)
            self.led.off(); time.sleep(0.05)

class ZPUCE_Ledger:
    def __init__(self):
        self.events = []

    def seal(self, event):
        h = 0
        for c in str(event):
            h = (h * 31 + ord(c)) & 0xFFFFFFFF
        event["hash"] = hex(h)[2:12] + "..."
        self.events.append(event)
        print(f"🔐 Ledger : {event['hash']}")

def main():
    zpuce = ZPUCE_CORE()
    ledger = ZPUCE_Ledger()
    zpuce.boot()
    while True:
        p = zpuce.perceive({"source": "LOCAL", "msg": "ping"})
        d = zpuce.decide(p)
        ledger.seal(d)
        time.sleep(5)

if __name__ == "__main__":
    main()
